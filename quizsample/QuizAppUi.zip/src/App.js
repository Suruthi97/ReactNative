import React from 'react';
import {
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Quiz from './screens/Quiz';

const App = () => {
  return (
   <Quiz/>
  );
};

const styles = StyleSheet.create({
});

export default App;
