
export const COLORS={
    primary:"#443850",
    secondary:"#7D8491",
    accent:"#BBBE64",
    success:"#00C851",
    error:"#ff4444",
    black:"#171717",
    white:"#FFFFFF",
    background:"#443850"
}